//
//  yippeeeeApp.swift
//  yippeeee
//
//  Created by Vijayaganapathy Pavithraa on 27/4/24.
//

import SwiftUI

@main
struct yippeeeeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
