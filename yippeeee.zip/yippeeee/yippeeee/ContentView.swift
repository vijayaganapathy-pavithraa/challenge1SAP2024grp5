//
//  ContentView.swift
//  yippeeee
//
//  Created by Vijayaganapathy Pavithraa on 27/4/24.
//

import SwiftUI

struct ContentView: View {
    @State private var cuisines = [
        "Drinks",
        "Western",
        "Chinese",
        "Indian",
        "Local"
    ]
    @State private var restaurants = [
        //drinks
        Restaurant(category: .drinks, name: "Starbucks", logo: UIImage(imageLiteralResourceName: "starbuckLogo"), food: UIImage(imageLiteralResourceName: "starbucks"), rating: "4.1", address: "1 Fusionopolis Link, #01-03 Nexus @one-north, Singapore 138542", openingHours: "Weekdays: 7am - 9pm\nWeekends: 8:30am - 5pm", menuLink: "https://www.starbucks.com.sg/menu", phoneNumber: "+65 6910 1215", priceRange: "$5-$15") ,
        Restaurant(category: .drinks, name: "Dutch Colony Coffee Co.", logo: UIImage(imageLiteralResourceName: "dutchColonyLogo"), food: UIImage(imageLiteralResourceName: "dutchColonyFood"), rating: "4.3", address: "1 Fusionopolis Wy, #01-01, Singapore 138632", openingHours: "8am-6pm", menuLink: "https://www.dutchcolony.sg/", phoneNumber: "+65 6914 9688", priceRange: "$10-S$30"),
        
        //western
        Restaurant(category: .western, name: "Pastamania", logo: UIImage(imageLiteralResourceName: "pastamanialogo"), food: UIImage(imageLiteralResourceName: "pastamaniafood"), rating: "3.7", address: "1 Fusionopolis Pl, #01-04 Fusionopolis One, Singapore 138632" , openingHours: "10:30 am–5 pm", menuLink: "https://www.pastamania.com.sg/menu", phoneNumber: "+65 6463 4018", priceRange: "$10-$15"),
        Restaurant(category: .western, name: "FoodBarn Galaxis", logo: UIImage(imageLiteralResourceName: "FoodbarnLogo"), food: UIImage(imageLiteralResourceName: "foodbarnfood"), rating: "4.1", address: "Galaxis, #01-13, 1 Fusionopolis Pl, Galaxis, 138522", openingHours: "11am-9.30pm", menuLink: "https://thefoodbarn.com.sg", phoneNumber: "+65 6804 6473", priceRange: "$10-20"),
        
        //indian
        Restaurant(category: .indian, name: "Raj Restaurant", logo: UIImage(imageLiteralResourceName: "rajlogo"), food: UIImage(imageLiteralResourceName: "rajfood"), rating: "3.8", address: "20 Biopolis Way, #01-03 Centros, Block 138668", openingHours: "11am to 3pm\n5pm to 9.30pm", menuLink: "https://raj-biopolis.oddle.me/en_SG", phoneNumber: "+65 8779 8702", priceRange: "$20-$30"),
        Restaurant(category: .indian, name: "Tayibba Biryani Restaurant", logo: UIImage(imageLiteralResourceName: "tbrlogo"), food: UIImage(imageLiteralResourceName: "tbrfood"), rating: "4.7", address: "1 Fusionopolis Link, #01-03 Nexus @one-north, Singapore 138542", openingHours: "Weekdays: 10.30am to 8pm\nSat: 11.30am to 5pm\nClosed Sun", menuLink: "https://www.tayyibabiryani.sg", phoneNumber: "+65 6993 9648", priceRange: "$10-$20"),
        
        //local
        Restaurant(category: .local, name: "Rong Hua Bak Kut Teh", logo: UIImage(imageLiteralResourceName: "rong hua logo"), food: UIImage(imageLiteralResourceName: "rhbkt"), rating: "4.5", address: "1 Fusionopolis Way # B1 - 13, 138632", openingHours: "10am - 3pm and 5pm-9pm\nClosed Sun", menuLink: "https://www.ronghua.com.sg", phoneNumber: "+65 6463 3138", priceRange: "$10-$20"),
        Restaurant(category: .local, name: "Traditional Sarawak Kolo Mee Fusionopolis", logo: UIImage(imageLiteralResourceName: "kolomeelogo"), food: UIImage(imageLiteralResourceName: "kolomeefood"), rating: "4.2", address: "1 Fusionopolis Way #B1-14 Connexis Building, One North MRT, 138632", openingHours: "Sunday: 10am - 3.30pm\nOther days: 9.30 am - 3 pm, 5 pm - 8 pm", menuLink: "https://www.traditionalkolomee.com", phoneNumber: "NA", priceRange: "$1-$10"),
        
        //chinese
        Restaurant(category: .chinese, name: "Wok Palace", logo: UIImage(imageLiteralResourceName: "wokpalacelogo"), food: UIImage(imageLiteralResourceName: "wokpalacefood"), rating: "4.1", address: "1 Fusionopolis Wy, #02-01/02, Singapore 138632", openingHours: "10am-10pm", menuLink: "https://wokpalace.wpenginepowered.com/main-menu/", phoneNumber: "+65 6909 9856", priceRange: "$10-$20"),
        Restaurant(category: .chinese, name: "Zhen Neng Zhu", logo: UIImage(imageLiteralResourceName: "zhennengzhulogo"), food: UIImage(imageLiteralResourceName: "zhennengzhufood"), rating: "4.1", address: "1 Fusionopolis Wy, B1-16, Singapore 138577", openingHours: "Mon-Sat : 8am-9pm , Closed Sunday", menuLink: "https://www.foodpanda.sg/restaurant/wj0j/zhen-neng-zhu-la-mian-and-xiao-long-bao-kallang-ave", phoneNumber: "NA", priceRange: "$10-$20")
    ]
    
    var body: some View {
        NavigationStack{
            List {
                ForEach (Category.allCases, id:\.hashValue) { category in
                    NavigationLink {
                        RestaurantListView(restaurant: category)
                    }label:{
                        Text(category.name)
                    }
                }
                
            }
            .navigationTitle("Cuisine")
        }
    }
}
#Preview {
    ContentView()
}
